/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guia3castillloalison;

/**
 *
 * @author casti
 */
public class GUIA3CASTILLLOALISON {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
